
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure
from bson.objectid import ObjectId
import urllib.parse  # ← add this!

class AnimalShelter:
    def __init__(self, username, password):
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 33319
        DB = 'AAC'
        COL = 'animals'

        try:
            # Encode credentials safely
            user = urllib.parse.quote_plus(username)
            passwd = urllib.parse.quote_plus(password)

            self.client = MongoClient(f"mongodb://{user}:{passwd}@{HOST}:{PORT}")
            self.database = self.client[DB]
            self.collection = self.database[COL]
        except (ConnectionFailure, OperationFailure) as e:
            print(f"Failed to connect to MongoDB: {e}")
            self.client = None


            
    def create(self, data): # Insert one document into the collection 
        if self.client is None:
            return False
        if isinstance(data, dict) and data:
            try:
                result = self.collection.insert_one(data)
                return result.acknowledged
            except OperationFailure as e:
                print(f"Insert failed: {e}")
                return False
        else:
            print("Invalid data input: Must be a non-empty dictionary")
            return False

    def read(self, query): # """ Find documents that match the query and return them as a list """
        if self.client is None:
            return []
        if isinstance(query, dict):
            try:
                results = list(self.collection.find(query))
                return results
            except OperationFailure as e:
                print(f"Read failed: {e}")
                return []
        else:
            print("Query must be a dictionary.")
            return []

    def update(self, query, new_values): # Update document(s) matching the query with the provided new values. Returns the number of documents modified.
        if self.client is None:
            return 0
        if isinstance(query, dict) and isinstance(new_values, dict):
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            except OperationFailure as e:
                print(f"Update failed: {e}")
                return 0
        else:
            print("Invalid input: query and new_values must be dictionaries.")
            return 0
        
    def delete(self, query): # Delete document(s) matching the query. Returns the number of documents deleted.
        if self.client is None:
            return 0
        if isinstance(query, dict):
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except OperationFailure as e:
                print(f"Delete failed: {e}")
                return 0
        else:
            print("Query must be a dictionary.")
            return 0
